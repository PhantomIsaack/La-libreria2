<!-- espera.php -->
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Espera Confirmación</title>
</head>
<body>
    <h1>Registro en Proceso</h1>
    <p>Te hemos enviado un correo electrónico. Por favor, confirma tu cuenta para completar el registro.</p>
</body>
</html>
