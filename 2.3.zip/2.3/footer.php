<footer>
    <a class="narrable" href="contactanos.php">Contáctanos</a>
        <div class="redes-sociales">
            <a class="narrable" href="https://www.google.com/url?sa=t&source=web&rct=j&opi=89978449&url=https://www.instagram.com/&ved=2ahUKEwjI4-Djn7qIAxUaM9AFHal4JdgQFnoECBIQAQ&usg=AOvVaw1cBeRoOpMhZ3-x5M1sA3Fm" class="icon">📷 Instagram</a>
            <a class="narrable" href="https://www.google.com/url?sa=t&source=web&rct=j&opi=89978449&url=https://www.whatsapp.com/%3Flang%3Des&ved=2ahUKEwjWjYW6oLqIAxUGHNAFHbEmBGIQFnoECB8QAQ&usg=AOvVaw3w5ZuBZZCvVWSbHbL5JCgG" class="icon">📱 WhatsApp</a>
            <a class="narrable" href="https://www.google.com/url?sa=t&source=web&rct=j&opi=89978449&url=https://www.facebook.com/%3Flocale%3Des_LA&ved=2ahUKEwj804jGoLqIAxWB6skDHQqTFnAQFnoECBQQAQ&usg=AOvVaw1I60-Ja6y72-wCvsxEihv7" class="icon">📘 Facebook</a>
        </div>

        <a href="#" class="narrable back-to-top">⬆️ Volver arriba</a>
</footer>

<script src="javajs/encab.js"></script>

</body>
</html>