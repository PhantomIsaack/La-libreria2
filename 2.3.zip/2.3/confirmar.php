<?php
// Conectar a la base de datos
require 'conexion.php';

$token = $_GET['token'];

// Verificar token
$query = "SELECT * FROM usuarios WHERE token = '$token' AND confirmado = 0";
$result = mysqli_query($conn, $query);

if (mysqli_num_rows($result) > 0) {
    // Actualizar estado de confirmación
    $query = "UPDATE usuarios SET confirmado = 1 WHERE token = '$token'";
    mysqli_query($conn, $query);
    header("Location: index.php"); // Redirigir a la página principal
} else {
    echo "Token inválido o ya confirmado.";
}
?>
