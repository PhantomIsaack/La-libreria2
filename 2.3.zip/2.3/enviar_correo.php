<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Incluye PHPMailer
require 'libs/PHPMailer-master/src/PHPMailer.php';
require 'libs/PHPMailer-master/src/SMTP.php';
require 'libs/PHPMailer-master/src/Exception.php';

// Incluye el archivo de configuración para obtener la URL base
require 'config.php';

function enviarCorreoConfirmacion($email, $token) {
    global $base_url; // Asegúrate de que la variable esté disponible en la función

    $mail = new PHPMailer();
    $mail->isSMTP();
    $mail->Host = 'smtp.hostinger.com'; // Servidor SMTP de Hostinger
    $mail->SMTPAuth = true;
    $mail->Username = 'noreply@lalibreriaayuditas.com'; // Tu correo
    $mail->Password = 'Noreply@2024.'; // Contraseña del correo
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS; // Usa SSL
    $mail->Port = 465; // Puerto para SSL

    $mail->setFrom('noreply@lalibreriaayuditas.com', 'La Librería');
    $mail->addAddress($email);
    $mail->Subject = 'Confirma tu correo';

    // Crea el enlace de confirmación utilizando la URL base de `config.php`
    $mail->Body = "Haz clic en el enlace para confirmar tu cuenta: " . $base_url . "/confirmar.php?token=" . $token;

    // Habilitar depuración para ver detalles del proceso (para pruebas)
    $mail->SMTPDebug = 0; // Cambia a 2 para depuración detallada
    $mail->Debugoutput = 'html';

    // Enviar el correo y verificar si hubo algún error
    if (!$mail->send()) {
        echo 'Error enviando correo: ' . $mail->ErrorInfo;
    } else {
        echo 'Correo enviado correctamente.';
    }
}
?>
