<?php
// URL base para el entorno local
$base_url = 'http://localhost/2.3';

// Cuando pases a producción, cambia a:
// $base_url = 'https://tu_dominio.com';
